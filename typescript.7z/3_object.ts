// Объекты в TypeScript ведут себя особым образом.
let date = {
    day: 1,
    month: "januar",
    year: 2024
}
// При объявлении объекта typeScript запоминает тип его свойств. И изменение этого типа будте вызывать ошибку.
// date.day = "monday" // будет вызывать ошибку, т.к. при обявлении свойтво day получило тип числовой(number);
// Так же typeScript контролирует что в переменной date находится именно объект!
// т.е. date = '12-08-1990' приведёт к ошибке.
// date.color = 'white' - такая запись так же приведёт к ошибке т.к. свойства color нет в объекте date.
// delete date.year такая запись вызовет ошибку.

// Вывод: В созданном таким образом объекте нельзя изменять (добавлять/удалять) свойства объекта. А так же изменять тип данных в свойствах объекта.
// ===========================================================================================================================================
// Структура объекта
// Можно не полагаться на typeScript при создании объекта, а в ручную указать его структуру.

// Пример 1: Отдельно задаём структуру, отдельно задаём данные.
let user0: { name: string, age: number };
user0 = { name: "John", age: 42 };
// Пример 2: Записываем данные вместе со структурой.
let user: { name: string, age: number } = { name: "John", age: 42 };
// После такого указания структуры объекта typeScript будет контролировать изменени типов объекта.
//user.name = 123; // подобная запись вызовет ошибку, т.к. свойство name в объекте user поддерживает только тип string

// При подобном задании структуры объекта можно сделать свойства "необязательными". Для этого после имени свойства достаточно поставить вопросительный знак.
//Пример:
let user2: { name: string, age: number, salary?: number };
user2 = { name: 'Mark', age: 40 }; // т.к. свойство salary необязательно его можно не указывать. А так же в последствии добавить или удалить.
user2.salary = 3000;


//===========================================================================================================================================
// Создание объекта при помощи интерфейса(interface)
// Сначала создаётся интерфейс, которые описывает типы имена свойств и типы данных которые в них хранятся (иными словами интерфейс описывает структуру объекта). Если после свойства поставить вопросительный знак, то значит это свойство не является обязательным. т.е. его можно несоздавать(и добавить позже). А если оно есть, то его можно удалить.
// Называть интерфейсы принято с большой буквы.
interface Iuser {
    name: string,
    surn?: string | null,
    age: number | null | undefined,
};
// После объявления объекта, через двоеточие указывается его интерфейс. Далее следует знак "равно"(=), и далее в фигурных скобках указываются свойства и через двоеточие их значения.

let userEric: Iuser = {
    name: 'Eric',
    age: 20
};

userEric.surn = null;
userEric.age = null;
console.log(userEric);
userEric.age = 30;
userEric.surn = 'Smith';
console.log(userEric);
delete userEric.surn
console.log(userEric);

// При создании новых интерфейсов(interface) можно наследовать свойства уже существующих интерфейсов.

interface Iexployee extends Iuser {
    salary?: number
}

let exp: Iexployee = {
    name: "John",
    age: 40,
    salary: 3000
}
exp.surn = 'Clinton'
console.log(exp)
delete exp.salary
console.log(exp)
//===========================================================================================================================================
// Массивы в объектах typeScript
// Объекты помимо примитивов могут содержать и другие данные. Например массивы.
// Пример 1: (сначала описываем структуру объекта, затем заполняем данные)
let prod: {
    name: string,
    colors: string[]
}
prod = {
    name: 'apple',
    colors: ['red', 'yellow', 'green']
}


// Пример 2: (Объявляем интерфейс. Затем создаём объект с использованием интерфейса.)
interface ICountry {
    name: string,
    area: number,
    city: string[]
}
let rossia: ICountry = {
    name: 'Rossia',
    area: 17_100_000,
    city: ['Moskow', 'Piter', 'Kazan']
}

//===========================================================================================================================================
// Сложные объекты в typeScript
// Объекты могут иметь внутри себя структуру любой вложенности. И эта структура может быть описана при помощи интерфейса.
// Пример 1:
interface Iuuser {
    name: string,
    age: number,
    parentsName: {
        mother: string,
        father: string
    }
}

let user3: Iuuser = {
    name: 'Bill',
    age: 70,
    parentsName: {
        mother: 'Lusi',
        father: 'Jack'
    }
}

// Задача 1
// написать интерфейс для объекта:
let event0: Ievents = {
    name: 'my new event',
    time: {
        start: '2025-11-01',
        finish: '2025-12-31'
    }
};
interface Ievents {
    name: string,
    time: {
        start: string,
        finish: string
    }
}
// написать интерфейс для объекта:
let employee: Iemployee1 = {
    name: 'andrew',
    position: {
        name: 'programmer',
        salary: 1000,
    },
    addr: {
        country: 'Belarus',
        city: 'minsk'
    }
};
interface Iemployee1 {
    name: string,
    position: {
        name: string,
        salary: number
    },
    addr: {
        country: string,
        city: string
    }
}

//==========================================================================================================================================
// Интерфейсы внутри других интерфейсов.
// Допустим у нас есть 2 интерфейса. Один описывает город, другой описывает пользователя.
interface Icity0 {
    name: string,
    country?: string | undefined
}
interface IUser0 {
    name: string,
    age: number
}
// Допустим нам в интерфейсе пользователя на надо указать город. В таком случае мы при описании интерфейса пользвателя можем добавить интерфейс города.
// Пример:
interface Icity1 {
    name: string,
    country?: string | undefined
}
interface IUser1 {
    name: string,
    age: number,
    city: Icity1
}

let user4: IUser1 = {
    name: "Max",
    age: 45,
    city: {
        name: 'Petropavlovsk',
        country: 'Rossia'
    }
}
// Задача 1
// Сделайте интерфейс, описывающий структуру этого объекта. Вынесите вложенные объекты в отдельные интерфейсы.
let employee22: IEmp0 = {
    name: 'andrew',
    position: {
        name: 'programmer',
        salary: 1000,
    },
    addr: {
        country: 'Belarus',
        city: 'minsk'
    }
};
interface IEmp0 {
    name: string
    position: IPos0,
    addr: IAddr0
}
interface IPos0 {
    name: string,
    salary: number
}
interface IAddr0 {
    country: string,
    city: string
}
// Задача 2
// Сделайте интерфейс, описывающий структуру этого объекта. Вынесите вложенные объекты в отдельные интерфейсы.
let user5: IUser2 = {
    name: 'john',
    age: 30,
    parents: {
        mother: {
            name: 'jane',
            age: 30,
            parents: null
        },
        father: {
            name: 'eric',
            age: 30,
            parents: null
        }
    }
}

interface IUser2 {
    name: string,
    age: number,
    parents: IParents0
}
interface IParents0 {
    mother: IParentsName0 | null,
    father: IParentsName0 | null
}
interface IParentsName0 {
    name: string,
    age: 30,
    parents: null | IParents0
}



















// Пример ..:
// interface IUser extends Iuser {
//     adress: {
//         street: string;
//         home: number
//     }
// }

// let guest: IUser = {
//     name: "Mark",
//     age: 40,
//     adress: {
//         street: 'beverli hyls',
//         home: 37
//     }
// }