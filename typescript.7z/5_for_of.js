"use strict";
// В цикле for of указывать тип не нужно. TypeScript укажет его самостоятельно.
let arr = [1, 2, 3, 4, 5];
let res5 = 0;
for (let elem of arr) {
    res5 += elem;
}
console.log(res5);
let arr51 = [1, 2, 3, 4, 'a'];
let res51 = 0;
for (let elem of arr51) {
    res51 += elem;
}
console.log(res51);
