"use strict";
// В цикле for in тип ключа так же не указывается.
let obj = { a: 1, 200: 'a', c: 3 };
for (let key in obj) {
    console.log(key, obj[key]);
}
// console.log(res);
