"use strict";
// Enum === перечисления.
// Перечисления используются для зания наборов значений которые известны заранее и не должны изменяться: (по сути аналог строчных литералов)
// Пример:
var yearTime;
(function (yearTime) {
    yearTime[yearTime["winter"] = 0] = "winter";
    yearTime[yearTime["spring"] = 1] = "spring";
    yearTime[yearTime["summer"] = 2] = "summer";
    yearTime[yearTime["autumn"] = 3] = "autumn";
})(yearTime || (yearTime = {}));
;
// Задача: Сделайте перечисление, содержащее дни недели.
var weekDay;
(function (weekDay) {
    weekDay[weekDay["monday"] = 0] = "monday";
    weekDay[weekDay["tuesday"] = 1] = "tuesday";
    weekDay[weekDay["wednesday"] = 2] = "wednesday";
    weekDay[weekDay["thursday"] = 3] = "thursday";
    weekDay[weekDay["friday"] = 4] = "friday";
    weekDay[weekDay["saturday"] = 5] = "saturday";
    weekDay[weekDay["sunday"] = 6] = "sunday";
})(weekDay || (weekDay = {}));
//=============================================================================
// Значения перечислений можно получать по числовому ключу как у массивов.
let day = weekDay[0];
console.log(day); //'monday'
//=============================================================================
// Так же у перечислений можно получать ключ по значению.
console.log(weekDay.friday); // 4
//=============================================================================
// Каждое перечисление создаёт свой тип данных. Который мы можем присвоить переменной
let current;
console.log(current = weekDay.sunday);
//=============================================================================
// Можно указать номер дня недели вручную.
current = 0; // т.к. у нас указан тип переменной weekDay, то мы можем указать только то числовое значение, которое есть в этом перечислении.
console.log(current);
console.log(weekDay[current]);
//=============================================================================
// Перечисления имеют автоматическую нумерацию, всегда начинающуюся с нуля. Но так же можно самостоятельно задавать числовые номера переменных в перечислении.
var direction;
(function (direction) {
    direction[direction["left"] = 5] = "left";
    direction[direction["up"] = 4] = "up";
    direction[direction["down"] = 5] = "down";
    direction[direction["right"] = 6] = "right";
})(direction || (direction = {}));
// После того как мы задали номер, остальная нумерация будет назначаться автоматически по возрастанию.
// let d:direction = 2; // error // typeScript отслеживает все номера перечислений. По этому задать можно только те номера которые присутствуют в перечислении.
let d2 = direction.left;
console.log(direction[d2]);
// Если номера в перечислении повторяются(что допустимо), то при запросе одинакового номера всегда выводится последние данные с совпадающим номером.
//=============================================================================
// В качестве ключей перечислений могуть быть не только числа, но и строки!
var Direction;
(function (Direction) {
    Direction["up"] = "\u0432\u0435\u0440\u0445";
    Direction["right"] = "\u043F\u0440\u0430\u0432\u043E";
    Direction["down"] = "\u043D\u0438\u0437";
    Direction["left"] = "\u043B\u0435\u0432\u043E";
})(Direction || (Direction = {}));
// При использовании в качестве ключей (инициализаторов) перечислений строковых значений. Их нужно указать все. т.к. Атоматического заполнения в данном случае не будет.
let dd = Direction["left"];
console.log(dd);
