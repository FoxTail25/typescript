// В цикле for in тип ключа так же не указывается.

// let obj = {
//     name: 'John',
//     age: 40,
//     salary: 3000
// }

// let obj = {a: 1, b: 2, c: 3};

// for (let key in obj) {
//     let a:any = obj[key];
// 	console.log(key, a);
// }

interface BaseObject {
	[key: string]: any,
}

let obj: BaseObject = { a: 1, 200: 'a', c: 3 };


for (let key in obj) {
	console.log(key, obj[key])
}

// console.log(res);