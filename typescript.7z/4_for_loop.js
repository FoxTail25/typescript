"use strict";
// Цикл For
// При создании цикла For, нужно указывать(необязательно) тип счётчика.
let res = 0;
for (let i = 1; i <= 5; i++) {
    res = i;
}
;
console.log(res, ' for with type');
// Без указания типа счетчика счётчику автоматически будет назначиться нужный тип.
let res2 = 0;
for (let i = 1; i <= 5; i++) {
    res2 = i;
}
;
console.log(res2, ' for without type');
