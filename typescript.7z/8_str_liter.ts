// Строковый литерал.
// Тип который объединяет в себе ограниченное число строковых значений.
let str: 'success' | 'error';

str = 'success';
str = 'error';

// других значений эта переменная принимать не может.
// Практика: Сделайте так, чтобы переменная могла принимать одно из трех значений: 'error', 'warning' или 'success'.
let answer: 'succes' | 'warning' | 'error';
answer = "warning";

// Так же для строчний литералов можно использовать "псевдонимы"(свои типы)
type message = 'succes' | 'error';
let serverAnswer: message = "error";