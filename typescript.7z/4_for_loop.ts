// Цикл For
// При создании цикла For, нужно указывать(необязательно) тип счётчика.
let res04:number = 0;
for(let i:number = 1; i <= 5; i++) {
    res04 = i
};
console.log(res, ' for with type')

// Без указания типа счетчика счётчику автоматически будет назначиться нужный тип.
let res2 = 0;
for(let i = 1; i <= 5; i++) {
    res2 = i
};
console.log(res2, ' for without type')
