"use strict";
// Объекты в TypeScript ведут себя особым образом.
let date = {
    day: 1,
    month: "januar",
    year: 2024
};
// При объявлении объекта typeScript запоминает тип его свойств. И изменение этого типа будте вызывать ошибку.
// date.day = "monday" // будет вызывать ошибку, т.к. при обявлении свойтво day получило тип числовой(number);
// Так же typeScript контролирует что в переменной date находится именно объект!
// т.е. date = '12-08-1990' приведёт к ошибке.
// date.color = 'white' - такая запись так же приведёт к ошибке т.к. свойства color нет в объекте date.
// delete date.year такая запись вызовет ошибку.
// Вывод: В созданном таким образом объекте нельзя изменять (добавлять/удалять) свойства объекта. А так же изменять тип данных в свойствах объекта.
// ===========================================================================================================================================
// Структура объекта
// Можно не полагаться на typeScript при создании объекта, а в ручную указать его структуру.
// Пример 1: Отдельно задаём структуру, отдельно задаём данные.
let user0;
user0 = { name: "John", age: 42 };
// Пример 2: Записываем данные вместе со структурой.
let user = { name: "John", age: 42 };
// После такого указания структуры объекта typeScript будет контролировать изменени типов объекта.
//user.name = 123; // подобная запись вызовет ошибку, т.к. свойство name в объекте user поддерживает только тип string
// При подобном задании структуры объекта можно сделать свойства "необязательными". Для этого после имени свойства достаточно поставить вопросительный знак.
//Пример:
let user2;
user2 = { name: 'Mark', age: 40 }; // т.к. свойство salary необязательно его можно не указывать. А так же в последствии добавить или удалить.
user2.salary = 3000;
;
// После объявления объекта, через двоеточие указывается его интерфейс. Далее следует знак "равно"(=), и далее в фигурных скобках указываются свойства и через двоеточие их значения.
let userEric = {
    name: 'Eric',
    age: 20
};
userEric.surn = null;
userEric.age = null;
console.log(userEric);
userEric.age = 30;
userEric.surn = 'Smith';
console.log(userEric);
delete userEric.surn;
console.log(userEric);
let exp = {
    name: "John",
    age: 40,
    salary: 3000
};
exp.surn = 'Clinton';
console.log(exp);
delete exp.salary;
console.log(exp);
//===========================================================================================================================================
// Массивы в объектах typeScript
// Объекты помимо примитивов могут содержать и другие данные. Например массивы.
// Пример 1: (сначала описываем структуру объекта, затем заполняем данные)
let prod;
prod = {
    name: 'apple',
    colors: ['red', 'yellow', 'green']
};
let rossia = {
    name: 'Rossia',
    area: 17100000,
    city: ['Moskow', 'Piter', 'Kazan']
};
let user3 = {
    name: 'Bill',
    age: 70,
    parentsName: {
        mother: 'Lusi',
        father: 'Jack'
    }
};
// Задача 1
// написать интерфейс для объекта:
let event0 = {
    name: 'my new event',
    time: {
        start: '2025-11-01',
        finish: '2025-12-31'
    }
};
// написать интерфейс для объекта:
let employee = {
    name: 'andrew',
    position: {
        name: 'programmer',
        salary: 1000,
    },
    addr: {
        country: 'Belarus',
        city: 'minsk'
    }
};
let user4 = {
    name: "Max",
    age: 45,
    city: {
        name: 'Petropavlovsk',
        country: 'Rossia'
    }
};
// Задача 1
// Сделайте интерфейс, описывающий структуру этого объекта. Вынесите вложенные объекты в отдельные интерфейсы.
let employee22 = {
    name: 'andrew',
    position: {
        name: 'programmer',
        salary: 1000,
    },
    addr: {
        country: 'Belarus',
        city: 'minsk'
    }
};
// Задача 2
// Сделайте интерфейс, описывающий структуру этого объекта. Вынесите вложенные объекты в отдельные интерфейсы.
let user5 = {
    name: 'john',
    age: 30,
    parents: {
        mother: {
            name: 'jane',
            age: 30,
            parents: null
        },
        father: {
            name: 'eric',
            age: 30,
            parents: null
        }
    }
};
// Пример ..:
// interface IUser extends Iuser {
//     adress: {
//         street: string;
//         home: number
//     }
// }
// let guest: IUser = {
//     name: "Mark",
//     age: 40,
//     adress: {
//         street: 'beverli hyls',
//         home: 37
//     }
// }
