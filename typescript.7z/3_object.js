"use strict";
// Объекты в TypeScript ведут себя особым образом.
let date = {
    day: 1,
    month: "januar",
    year: 2024
};
;
// После объявления объекта, через двоеточие указывается его интерфейс. Далее следует знак "равно"(=), и далее в фигурных скобках указываются свойства и через двоеточие их значения.
let userEric = {
    name: 'Eric',
    age: 20
};
userEric.surn = null;
userEric.age = null;
console.log(userEric);
userEric.age = 30;
userEric.surn = 'Smith';
console.log(userEric);
delete userEric.surn;
console.log(userEric);
let exp = {
    name: "John",
    age: 40,
    salary: 3000
};
exp.surn = 'Clinton';
console.log(exp);
delete exp.salary;
console.log(exp);
