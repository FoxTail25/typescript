// В цикле for of указывать тип не нужно. TypeScript укажет его самостоятельно.
let arr = [1, 2, 3, 4, 5];
let res5 = 0;

for (let elem of arr) {
	res5 += elem;
}
console.log(res5);
// вышеописанный код будет работать не вызывая ошибки. Но лучше его типизировать.

type StrNum = number | string;
let arr51: StrNum[] = [1, 2, 3, 4,'a'];
let res51: any = 0;

for (let elem of arr51) {
	res51 += elem;
}
console.log(res51);